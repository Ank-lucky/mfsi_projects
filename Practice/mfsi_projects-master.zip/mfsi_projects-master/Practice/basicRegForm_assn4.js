function clicked(){
    alert("hi");
}

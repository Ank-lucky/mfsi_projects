try{
 throw "myException"
}
catch(e){
    logMyErrors(e);
}